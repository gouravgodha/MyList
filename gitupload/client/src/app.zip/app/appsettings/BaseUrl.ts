// Base url of project

export class APIEndpoint{
	
	public static BaseUrl='http://localhost:4217/';	
	
}

export class APIEndpoint2{	
	
//	public static BaseUrl='http://192.168.1.7:4217/';	
	// public static BaseUrl='https://syscraft-barpos.tk:4217/';	
	 public static BaseUrl='https://eviden.syscraft-pro.tk:4217/';	

}